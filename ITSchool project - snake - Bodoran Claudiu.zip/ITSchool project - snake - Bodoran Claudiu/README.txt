Pentru a putea rula joculetul trebuie sa aveti instalata libraria RAYLIB in calea urmatoare: C:\raylib
Aceasta biblioteca se poate descarca de pe siteul https://www.raylib.com/